#!/usr/bin/env python3
import random
from brain_games.cli import welcome_user


def main():
    print('Welcome to the Brain Games!')
    name = welcome_user()
    get_num_and_res(name)


def is_even(num):
    return num % 2 == 0


def get_num_and_res(name):
    print('Answer "yes" if the number is even, otherwise answer "no".')
    num = random.randint(1, 100)
    print(f'Question: {num}')
    result = 'yes' if is_even(num) else 'no'
    
    return get_user_answer(result, name)


def get_user_answer(res, name):
    user_answr = input('Your answer: ')
    if user_answr == res:
        print('Correct!')
    else:
        print(f'''{user_answr} is wrong answer ;(. Correct answer was {res}.\nLet's try again, {name}!''')
